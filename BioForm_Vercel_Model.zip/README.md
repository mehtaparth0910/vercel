# BioForm — Biomimicry Explorer

A responsive interactive static website for a college Biology project. It includes three selectable concept diagrams:
1. Kingfisher-inspired Shinkansen nose and tunnel pressure waves
2. Owl feather structures and aerodynamic noise
3. Humpback whale tubercles and blade flow behaviour

## Run locally
Open `index.html` in a modern browser. No dependencies or build step are required.

## Deploy to Vercel using GitHub
1. Extract this ZIP.
2. Create a GitHub repository (for example, `bioform-biomimicry`) and upload `index.html`, `vercel.json`, and this README.
3. Sign in to Vercel and select **Add New → Project**.
4. Import your GitHub repository.
5. Select **Other** as the framework preset. No build command is required for this static HTML project.
6. Click **Deploy**. Vercel will provide your live URL.

The airflow diagrams and slider are conceptual illustrations, not computational fluid dynamics simulations or measured performance data.
